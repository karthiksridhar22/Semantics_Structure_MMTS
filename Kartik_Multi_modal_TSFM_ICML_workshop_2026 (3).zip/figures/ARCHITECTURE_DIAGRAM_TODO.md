# Optional Figure 2 — three-panel architecture diagram

## Why this would help (per writing feedback §7a, Option C)

The reviewer's main mental model question after §2 is *"where does
$\mathbf{p}$ enter the fusion path, and is it on the same residual
as $\mathbf{T}$?"*  A simple 3-panel block diagram answers this
visually in one second; the three equations in §2 take a paragraph.

A figure here is currently *not* required (the fusion equations
already cover the content), but it would convert §2 into a
scan-and-go section and free up half a column for additional
discussion.

## Recommended layout

A `figure*` (full text width) split into three equal columns, one
per architecture, drawn with `tikz` or hand-drawn and embedded as
PDF. Each column has the same y-axis ordering:

```
   ┌──────────────┐ ┌──────────────┐ ┌──────────────┐
   │  TaTS         │  MM-TSFLIB    │  Aurora        │
   │  (early)      │  (late)       │  (cross-attn)  │
   ├──────────────┤ ├──────────────┤ ├──────────────┤
   │ x  T  p       │ x  T  p       │ x  T           │
   │ │  │  │       │ │  │  │       │ │  │           │
   │ │  ϕ  │       │ │  ϕ  │       │ │  BERT        │
   │ │  │  │       │ │  │  │       │ │  │           │
   │ │  ψ  │       │ │  pool        │ │  Q→Distill  │ ← Probe A grad
   │ │  │  │       │ │  │  │       │ │  │           │
   │ ▼  ▼  │       │ f_θ │  │      │ f_θ ← α_t      │ ← Probe B α
   │ concat │       │ │   │  │      │ │              │
   │ ▼      │       │ ▼   ▼  │      │ ▼              │
   │ f_θ    │       │ residual ←──── │ ŷ              │
   │ │      │       │ │              │                │
   │ ▼  +───┘       │ ŷ              │                │
   │ ŷ              │                │                │
   └──────────────┘ └──────────────┘ └──────────────┘
   ▲              ▲ ▲              ▲ ▲              ▲
   path-sharing:    path-sharing:    no path-sharing
   T and p sum      T and p sum      (p is unused)
   on the same       inside the
   residual          residual
```

## Annotations

In each panel, mark with a coloured tag:

- **Blue dot** at the location where Probe A would attach (the
  trainable hand-off after the text encoder, distillation, or
  projection).
- **Red dashed line** showing where C9 zeroes the prior column.
- **Green dashed line** showing where C2/C5 zero the text column.
- **Magenta line** showing where C6's architectural unimodal flag
  cuts the text branch and (for TaTS/MM-TSFLIB) the prior branch.

The visual punchline is that the red and magenta cuts coincide on
TaTS and MM-TSFLIB, and the magenta cut is empty on Aurora because
$\mathbf{p}$ never enters its graph.

## Drop-in LaTeX after drawing

Place the figure right after `\input{tab_main}` and before the
results paragraphs:

```latex
\begin{figure*}[t]
\centering
\includegraphics[width=\linewidth]{figures/fig_architectures.pdf}
\caption{\textbf{Where the prior enters the fusion path.}
TaTS and \MMTSF{} sum the text path with the prior column on the
same residual; \Aurora{} does not consume the prior. Coloured cuts
mark the perturbations of \cref{tab:perturbations}.}
\label{fig:architectures}
\end{figure*}
```

## Skipped for now because

(i) the 5-page body is already at the workshop limit and the
fusion equations already convey the residual-sharing story; (ii)
producing this figure cleanly requires either tikz expertise or a
vector-drawing pass, which is out of scope for the current revision.
