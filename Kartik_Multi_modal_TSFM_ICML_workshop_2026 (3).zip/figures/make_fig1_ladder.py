"""Generate Figure 1 (paper) -- three-panel perturbation ladder.

Clean horizontal-bar layout, one panel per architecture. Colour coding
separates text-only perturbations (blue) from prior-zeroed perturbations
(red) and the architectural unimodal flag (green). Numeric labels are
placed outside the bars to avoid overlap with bar fills.

Data is hard-coded from the locked main-results tables
(paper/tab_main.tex and paper/tab_appendix_perbackbone.tex) so the
figure is reproducible without the summaries/ pipeline.

Outputs: paper/figures/fig1_ladder.pdf, paper/figures/fig1_ladder.png
"""
from __future__ import annotations
from pathlib import Path

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

OUT_DIR = Path(__file__).resolve().parent

# ---------------------------------------------------------------------
# Data: mean delta-MSE (% vs C1) per (architecture, condition).
# Aurora values are the Avg column of tab_main.tex.
# MM-TSFlib and TaTS are cross-backbone averages over the three
# canonical backbones (DLinear, Informer, iTransformer) from
# tab_appendix_perbackbone.tex.
# ---------------------------------------------------------------------
PCT = {
    # condition: (aurora, mmtsflib, tats)
    "C3":  ( 0.003,  0.03,  0.003),
    "C4":  (-0.012,  0.01, -0.002),
    "C8":  ( 0.023,  0.06,  0.002),
    "C6":  ( 0.000,  1.79,  5.18),
    "C9":  ( 0.000,  2.48, 31.98),
    "C2":  ( 0.023,  2.51, 31.98),
    "C5":  ( 0.030,  2.52, 31.98),
}

# Vertical order within each panel. Grouped by cluster so the
# two-cluster dichotomy is glanceable.
ROW_ORDER = ["C3", "C4", "C8", "C6", "C9", "C2", "C5"]
ROW_LABELS = {
    "C3": "C3  within-domain shuffle",
    "C4": "C4  cross-domain swap",
    "C8": "C8  oracle (future values)",
    "C6": "C6  unimodal flag",
    "C9": "C9  zero priors",
    "C2": "C2  empty text, priors zeroed",
    "C5": "C5  constant text, priors zeroed",
}
CLUSTER = {
    "C3": "text", "C4": "text", "C8": "text",
    "C6": "uni",
    "C9": "prior", "C2": "prior", "C5": "prior",
}
COLOURS = {
    "text":  "#3e6fa3",   # muted blue
    "prior": "#b34a4a",   # muted red
    "uni":   "#4a8565",   # muted green
}

# (col_idx, title, xlim, x-tick step).
MODELS = [
    (0, "Aurora (zero-shot)",     (-0.04, 0.12),  0.04),
    (1, "MM-TSFlib (late fusion)",(-0.6,  4.5),   1.0 ),
    (2, "TaTS (early fusion)",    (-4.0, 46.0),  10.0 ),
]


def _format_pct(v: float) -> str:
    if abs(v) < 0.01:
        return f"{v:+.3f}%".replace("+0.000", "0.000")
    if abs(v) < 1:
        return f"{v:+.2f}%"
    return f"{v:+.1f}%"


def main() -> None:
    plt.rcParams.update({
        "font.family": "serif",
        "font.size": 9,
        "axes.titlesize": 10,
        "axes.labelsize": 9,
        "xtick.labelsize": 8.5,
        "ytick.labelsize": 9,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })

    # Slightly taller panels so bars have breathing room.
    fig = plt.figure(figsize=(7.2, 2.7))
    # Left column is wider (it carries the y-tick labels).
    gs = fig.add_gridspec(
        nrows=1, ncols=3,
        width_ratios=[1.55, 1.0, 1.05],
        wspace=0.18,
        left=0.015, right=0.995, top=0.82, bottom=0.22,
    )
    axes = [fig.add_subplot(gs[0, i]) for i in range(3)]

    for ax_idx, (col_idx, title, xlim, xstep) in enumerate(MODELS):
        ax = axes[ax_idx]
        ys = list(range(len(ROW_ORDER)))
        vals = [PCT[c][col_idx] for c in ROW_ORDER]
        colours = [COLOURS[CLUSTER[c]] for c in ROW_ORDER]

        bars = ax.barh(ys, vals, color=colours, edgecolor="none", height=0.62)
        ax.axvline(0, color="black", linewidth=0.7, zorder=3)

        # y-axis: labels only on the leftmost panel.
        ax.set_yticks(ys)
        if ax_idx == 0:
            ax.set_yticklabels([ROW_LABELS[c] for c in ROW_ORDER])
        else:
            ax.set_yticklabels([])
        ax.invert_yaxis()
        ax.set_ylim(len(ROW_ORDER) - 0.4, -0.6)

        # Horizontal cluster separators between (text / uni / prior) groups.
        ax.axhline(2.5, color="#cccccc", linewidth=0.4, zorder=1)
        ax.axhline(3.5, color="#cccccc", linewidth=0.4, zorder=1)

        ax.set_xlim(*xlim)
        ticks = []
        t = 0.0
        while t >= xlim[0]:
            ticks.insert(0, round(t, 4))
            t -= xstep
        t = xstep
        while t <= xlim[1]:
            ticks.append(round(t, 4))
            t += xstep
        ax.set_xticks(ticks)
        ax.set_title(title, pad=8, fontweight="normal")
        ax.set_xlabel(r"$\Delta$MSE (% vs C1)", labelpad=3)

        for spine in ("top", "right"):
            ax.spines[spine].set_visible(False)
        for spine in ("left", "bottom"):
            ax.spines[spine].set_color("#555555")
            ax.spines[spine].set_linewidth(0.8)
        ax.tick_params(length=3, width=0.6, colors="#555555")
        ax.grid(axis="x", linewidth=0.3, color="#e0e0e0", zorder=0)
        ax.set_axisbelow(True)

        # Value labels placed immediately outside each bar tip.
        span = xlim[1] - xlim[0]
        pad = 0.015 * span
        for b, v in zip(bars, vals):
            txt = _format_pct(v)
            if v >= 0:
                ax.text(
                    v + pad, b.get_y() + b.get_height() / 2, txt,
                    ha="left", va="center", fontsize=8, color="#222222",
                )
            else:
                ax.text(
                    v - pad, b.get_y() + b.get_height() / 2, txt,
                    ha="right", va="center", fontsize=8, color="#222222",
                )

    # Shared legend centred below the panels.
    handles = [
        mpatches.Patch(color=COLOURS["text"],  label="text-only perturbation"),
        mpatches.Patch(color=COLOURS["uni"],   label="architectural unimodal flag"),
        mpatches.Patch(color=COLOURS["prior"], label="prior column zeroed"),
    ]
    fig.legend(
        handles=handles, ncol=3, frameon=False, fontsize=9,
        loc="lower center", bbox_to_anchor=(0.55, -0.02),
        handlelength=1.0, handletextpad=0.5, columnspacing=1.8,
    )

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    pdf = OUT_DIR / "fig1_ladder.pdf"
    png = OUT_DIR / "fig1_ladder.png"
    fig.savefig(pdf, bbox_inches="tight", pad_inches=0.04)
    fig.savefig(png, bbox_inches="tight", pad_inches=0.04, dpi=220)
    print(f"wrote {pdf}\nwrote {png}")


if __name__ == "__main__":
    main()
